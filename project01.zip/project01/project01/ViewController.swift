//
//  ViewController.swift
//  project01
//
//  Created by Li, Xinli on 6/21/16.
//  Copyright (c) 2016 Li, Xinli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

 
    @IBOutlet weak var lable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func record(sender: AnyObject) {
        print("asdsda")
        lable.text = "tapped"
    }
  
   }

