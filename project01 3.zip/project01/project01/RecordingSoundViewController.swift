//
//  ViewController.swift
//  project01
//
//  Created by Li, Xinli on 6/21/16.
//  Copyright (c) 2016 Li, Xinli. All rights reserved.
//

import UIKit
import AVFoundation


class RecordingSoundViewController: UIViewController, AVAudioRecorderDelegate {

    @IBOutlet weak var Recording: UIButton!
    @IBOutlet weak var StopRecording: UIButton!
    @IBOutlet weak var lable: UILabel!
    var audioRecorder:AVAudioRecorder!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func stopRecording(sender: AnyObject) {
        lable.text = "nothing"
        StopRecording.enabled = false
        Recording.enabled = true
        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        //try! audioSessionn.setActive(false)

    }
    @IBAction func record(sender: AnyObject) {
        print("asdsda")
        lable.text = "Recording ...."
        StopRecording.enabled = true
        Recording.enabled = false
        let dirPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = NSURL.fileURLWithPathComponents(pathArray)
        print(filePath)
        let session = AVAudioSession.sharedInstance()
        session.setCategory(AVAudioSessionCategoryPlayAndRecord, error : nil)
        audioRecorder = AVAudioRecorder(URL: filePath!, settings: [:], error: nil)
        
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    override func viewWillAppear(animated: Bool) {
        StopRecording.enabled = false
    }
    
    
    
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder!, successfully flag: Bool) {
        
        if(flag){
            self.performSegueWithIdentifier("stop recording", sender: audioRecorder.url)}
        else{
        print("saving fail")
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "stopRecording") {
            let playSoundsVC = segue.destinationViewController as PlaySoundViewController
            let recordedAudioURL = sender as NSURL
                playSoundsVC.recordedAudioURL = recordedAudioURL
        }
    }
   }
