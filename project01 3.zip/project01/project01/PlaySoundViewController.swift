//
//  PlyaerSoundViewController.swift
//  project01
//
//  Created by Li, Xinli on 6/23/16.
//  Copyright (c) 2016 Li, Xinli. All rights reserved.
//

import UIKit
import AVFoundation
class PlaySoundViewController: UIViewController {
   
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    var recordedAudioURL: NSURL!
    var audioFile : AVAudioFile!
    var audioPlayNode: AVAudioPlayerNode!
    var stopTimer: NSTimer!
    var recordAudio: NSURL!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view.
    }
    
    @IBAction func stopButton(sender: UIButton) {
        print("play")
    }
    var recordedAudio: NSURL!
    @IBAction func plyButton(sender: AnyObject) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "stopRecording") {
            //let playSoundsVC = segue.destinationViewController as! PlaySoundsViewController
            //let recordedAudioURL = sender as! NSURL
           // playSoundsVC.recordedAudioURL = recordedAudioURL
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
